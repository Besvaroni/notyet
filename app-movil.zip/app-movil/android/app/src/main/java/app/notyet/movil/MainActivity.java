package app.notyet.movil;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
