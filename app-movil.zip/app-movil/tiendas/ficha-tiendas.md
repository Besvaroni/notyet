# Ficha para App Store y Google Play

Nombre: Not Yet
Subtítulo (App Store, 30 caracteres): Frena antes de pagar
Descripción corta (Google Play, 80 caracteres): Frena un segundo antes de pagar y convierte cada capricho que no compras en ahorro.
Categoría: Finanzas (secundaria: Estilo de vida)
Edad: 4+ / PEGI 3. Sin compras dentro de la app, sin anuncios.
Identificador: app.notyet.movil

Descripción larga:
Not Yet frena un segundo cuando vas a comprar por impulso. Te enseña lo que esa compra significa de verdad (horas de tu trabajo y lo que te acerca a tu destino) y te da tres salidas: esperar 24 horas, buscar más barato o preguntar a tu comité de amigos o a tu pareja. Comprar igualmente está siempre a un toque: Not Yet frena, no prohíbe.

Cada compra que descartas se apunta en el ticket del mes, alimenta un bote repartido entre tus destinos (un viaje, un regalo, la entrada de un piso) y suma puntos, niveles e insignias. Tu evolución por semana, mes o año, descargable en CSV o JSON, y un asistente que responde con tus datos.

Tus datos se quedan en tu móvil. Not Yet no se conecta a tu banco ni vigila tu navegación. Los consejos sobre dinero son reglas generales y no son asesoramiento financiero.

Privacidad: datos guardados solo en el dispositivo; sin recogida de datos por parte del desarrollador (etiqueta "Datos no recopilados" en App Store y "Sin datos recopilados ni compartidos" en Google Play), salvo lo que el usuario envíe a la IA que configure con su propia clave. Política: privacidad.html del kit, publicada en una dirección pública.
Palabras clave (App Store, 100 caracteres): ahorro,compras impulsivas,presupuesto,gastos,finanzas personales,objetivos,hábitos,consumo
