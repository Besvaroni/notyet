// NotYet - proceso de fondo
// Mantiene una alarma por cada compra en espera y avisa cuando pasan las 24 horas.
const H = 3600e3;
const PREFIX = "esperate-";

async function getItems() {
  const d = await chrome.storage.local.get("items");
  return Array.isArray(d.items) ? d.items : [];
}
async function setItems(items) { await chrome.storage.local.set({ items }); }

// Crea las alarmas que falten y borra las que sobren. Se llama al instalar, al arrancar y cada vez que cambian los datos.
async function reconcile() {
  const items = await getItems();
  const alarms = await chrome.alarms.getAll();
  const have = new Set(alarms.filter((a) => a.name.startsWith(PREFIX)).map((a) => a.name));
  const want = new Set();
  for (const it of items) {
    if (it.status === "wait" && !it.notified) {
      const name = PREFIX + it.id;
      want.add(name);
      if (!have.has(name)) chrome.alarms.create(name, { when: Math.max(Date.now() + 1000, it.start + (it.hours || 24) * H) });
    }
  }
  for (const name of have) if (!want.has(name)) chrome.alarms.clear(name);
}
chrome.runtime.onInstalled.addListener(reconcile);
chrome.runtime.onStartup.addListener(reconcile);
chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes.items) reconcile(); });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith(PREFIX)) return;
  const id = Number(alarm.name.slice(PREFIX.length));
  const items = await getItems();
  const it = items.find((i) => i.id === id);
  if (!it || it.status !== "wait") return;
  it.notified = true;
  await setItems(items);
  const price = it.price ? " (" + it.price.toLocaleString("es-ES") + " €)" : "";
  chrome.notifications.create(alarm.name, {
    type: "basic",
    iconUrl: "icons/128.png",
    title: "Han pasado 24 horas",
    message: "¿Sigues queriendo " + it.name + price + "?",
    buttons: [{ title: "No lo compro, lo ahorro" }, { title: "Lo compro" }],
    requireInteraction: true,
    priority: 2
  });
});

async function decide(nid, status) {
  const id = Number(nid.slice(PREFIX.length));
  const items = await getItems();
  const it = items.find((i) => i.id === id);
  if (!it) return;
  if (status) { it.status = status; it.decided = Date.now(); await setItems(items); }
  if ((status === "buy" || !status) && it.url) chrome.tabs.create({ url: it.url });
  chrome.notifications.clear(nid);
}
chrome.notifications.onButtonClicked.addListener((nid, idx) => { if (nid.startsWith(PREFIX)) decide(nid, idx === 0 ? "skip" : "buy"); });
chrome.notifications.onClicked.addListener((nid) => { if (nid.startsWith(PREFIX)) decide(nid, null); });

// Votación por enlace: se crea desde aquí para que funcione en cualquier tienda
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "notyet-poll") return;
  fetch("https://notyet-pagos.alfonsodeborbon-02.workers.dev/poll", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(msg.body || {}) })
    .then((r) => r.json()).then((j) => reply(j)).catch(() => reply({ ok: false }));
  return true;
});
