// NotYet - content script
// Se queda dormido en cualquier tienda y solo actúa cuando pulsas el botón de pagar: muestra el freno antes de que se envíe la compra.
// Recuerda el último producto que viste en esa tienda para que, en el carrito, las alternativas sean de ese producto y no genéricas.
(() => {
  "use strict";
  if (window.__notyetLoaded) return;
  window.__notyetLoaded = true;

  // Textos de botones que significan "voy a pagar" (sin acentos, en minúsculas; se normaliza antes de comparar)
  const PHRASES = [
    "tramitar pedido", "tramitar el pedido", "realizar pedido", "realizar el pedido", "confirmar pedido", "confirmar el pedido",
    "procesar pedido", "procesar el pedido", "finalizar compra", "finalizar la compra", "finalizar pedido", "finalizar el pedido",
    "hacer pedido", "hacer el pedido", "comprar ahora", "comprar ya", "confirmar y pagar", "confirmar compra", "confirmar la compra",
    "pagar ahora", "ir a pagar", "proceder al pago", "continuar al pago", "continuar con el pago", "pagar pedido", "realizar pago",
    "realizar el pago", "finalizar y pagar", "tramitar compra", "tramitar la compra", "completar compra", "completar pedido",
    "comprar y pagar", "pagar y finalizar", "ir a caja", "pasar por caja", "tramitar", "pedir y pagar", "confirmar y pedir", "hacer mi pedido", "realizar mi pedido",
    "place order", "place your order", "buy now", "proceed to checkout", "continue to checkout", "continue to payment",
    "pay now", "complete purchase", "complete order", "go to checkout", "checkout now", "secure checkout"
  ];
  const EXACT = new Set(["comprar", "pagar", "pedir", "checkout", "pedir ahora", "comprar articulo", "comprar producto"]);
  const PHRASE_RE = new RegExp("(?:^|\\b)(" + PHRASES.map((p) => p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|") + ")\\b", "i");
  const BYPASS_MS = 2 * 60 * 1000;
  let bypassUntil = 0;
  let open = false;

  const norm = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
    .replace(/\(\s*\d+\s*\)/g, " ").replace(/\s+/g, " ").trim();
  const textOf = (el) => norm([
    el.innerText, el.value, el.getAttribute && el.getAttribute("aria-label"), el.getAttribute && el.getAttribute("title")
  ].filter(Boolean).join(" ")).slice(0, 80);
  const isBuyText = (t) => !!t && t.length <= 60 && (EXACT.has(t) || PHRASE_RE.test(t));
  const isClickable = (el) => {
    const tag = el.tagName;
    return tag === "BUTTON" || tag === "A" || (tag === "INPUT" && /^(submit|button|image)$/i.test(el.type || "")) || el.getAttribute("role") === "button";
  };
  function findBuyButtonsNow() {
    const out = [];
    document.querySelectorAll("button, a, input[type=submit], input[type=button], [role=button]").forEach((el) => {
      if (isBuyText(textOf(el)) && el.offsetParent !== null) out.push(el);
    });
    return out;
  }

  // Precio: primero selectores conocidos (Amazon), luego cualquier "total" visible, luego cualquier precio
  function parseEuro(t) {
    const s = String(t || "").replace(/ /g, " ");
    const m = s.match(/(\d{1,3}(?:[.\s]\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s?(?:€|eur\b)/i) || s.match(/(?:€|eur)\s?(\d{1,3}(?:[.\s]\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)/i);
    if (!m) return null;
    let raw = (m[1] || "").replace(/\s/g, "");
    if (/,\d{1,2}$/.test(raw)) raw = raw.replace(/\./g, "").replace(",", ".");
    else if (/\.\d{3}(\.|$)/.test(raw)) raw = raw.replace(/\./g, "");
    const v = parseFloat(raw);
    return v > 0 && v < 100000 ? v : null;
  }
  function priceFrom(sel) {
    let nodes; try { nodes = document.querySelectorAll(sel); } catch (e) { return null; }
    for (const n of nodes) {
      if (!(n.offsetParent || n.classList.contains("a-offscreen"))) continue;
      const t = n.textContent || "";
      if (t.length > 120) continue;
      const v = parseEuro(t); if (v) return v;
    }
    return null;
  }
  function guessPrice() {
    const sels = [
      "#sc-subtotal-amount-buybox", "#sc-subtotal-amount-activecart", "#subtotals-marketplace-table .grand-total-price",
      ".order-summary-line-definition", "#corePriceDisplay_desktop_feature_div .priceToPay", "#corePrice_feature_div .a-offscreen",
      "#corePriceDisplay_desktop_feature_div .a-offscreen", "#apex_desktop .a-offscreen",
      "[data-testid*='total' i]", "[class*='grand-total' i]", "[class*='order-total' i]", "[class*='total-price' i]",
      "[class*='totalprice' i]", "[class*='cart-total' i]", "[id*='subtotal' i]", "[id*='total' i]", "[class*='total' i]"
    ];
    for (const s of sels) { const v = priceFrom(s); if (v) return v; }
    // Último recurso: una línea corta que diga "total" con un importe
    for (const el of document.querySelectorAll("div, span, p, td, dd, li")) {
      const t = el.textContent || "";
      if (t.length < 60 && /total/i.test(t)) { const v = parseEuro(t); if (v) return v; }
    }
    return priceFrom("[class*='price' i]");
  }
  const shopKey = location.hostname.replace(/^www\./, "").split(".").slice(-2, -1)[0] || location.hostname;
  const SHOP_NAMES = { amazon: "Amazon", zara: "Zara", shein: "Shein", zalando: "Zalando", aliexpress: "AliExpress", temu: "Temu",
    elcorteingles: "El Corte Inglés", mediamarkt: "MediaMarkt", pccomponentes: "PcComponentes", decathlon: "Decathlon",
    primor: "Primor", druni: "Druni", bershka: "Bershka", pullandbear: "Pull&Bear", mango: "Mango", vinted: "Vinted", wallapop: "Wallapop",
    mercadona: "Mercadona", glovoapp: "Glovo", mcdonalds: "McDonald's", "ray-ban": "Ray-Ban", nike: "Nike", adidas: "Adidas", ikea: "IKEA", carrefour: "Carrefour", fnac: "Fnac", apple: "Apple", hm: "H&M", uniqlo: "Uniqlo", sephora: "Sephora", booking: "Booking", ryanair: "Ryanair", vueling: "Vueling", ebay: "eBay" };
  const shopName = SHOP_NAMES[shopKey] || (shopKey.charAt(0).toUpperCase() + shopKey.slice(1));
  const CART_RE = /^(cesta|carrito|mi cesta|tu cesta|cesta de la compra|shopping cart|cart|basket|pedido|tramitar|checkout|pago|finalizar|iniciar sesi)/i;
  const clean = (t) => (t || "").replace(/\s+/g, " ").trim();
  function guessName() {
    // 1) Título del producto en la página (Amazon y tiendas con h1), 2) og:title, 3) título de la pestaña sin el nombre de la tienda
    const cands = [];
    const p = document.querySelector("#productTitle, h1.product-title, h1[class*='title' i], h1");
    if (p) cands.push(clean(p.textContent));
    const og = document.querySelector('meta[property="og:title"]');
    if (og) cands.push(clean(og.getAttribute("content")));
    const dt = clean(document.title);
    if (dt) {
      const parts = dt.split(/\s[|:\-–]\s/).map(clean).filter((x) => x.length > 3 && !new RegExp(shopName, "i").test(x) && !/amazon|\.es$|\.com$/i.test(x));
      parts.sort((a, b) => b.length - a.length);
      if (parts[0]) cands.push(parts[0]);
    }
    for (const t of cands) { if (t && t.length >= 3 && !CART_RE.test(t)) return t.slice(0, 90); }
    return "";
  }
  // Productos que hay en el carrito (Amazon y tiendas habituales)
  function cartNames() {
    const sels = [".sc-product-title", ".sc-grid-item-product-title", "[data-name='Active Items'] .a-truncate-full", "[class*='cart' i] [class*='product-name' i]", "[class*='cart' i] [class*='item-name' i]", "[class*='basket' i] [class*='name' i]", "[class*='cart-item' i] a", "[class*='line-item' i] [class*='title' i]", "[class*='product-item' i] [class*='name' i]", "[data-testid*='product-name' i]"];
    const out = [];
    for (const sel of sels) { let n; try { n = document.querySelectorAll(sel); } catch (e) { continue; } n.forEach((x) => { const t = clean(x.textContent); if (t.length >= 4 && t.length <= 140 && !CART_RE.test(t) && !out.includes(t)) out.push(t); }); if (out.length) break; }
    return out.slice(0, 5);
  }
  const ONPRODUCT = () => !!document.querySelector('#productTitle, [itemtype*="schema.org/Product"], meta[property="og:type"][content*="product" i], meta[property="product:price:amount"]') || /\/(dp|p|product|producto|item)\//i.test(location.pathname);
  // Al ver una ficha de producto, se recuerda (solo en este navegador) para usarlo en el carrito
  function rememberProduct() { try { if (!ONPRODUCT()) return; const n = guessName(); if (!n) return; const p = guessPrice(); chrome.storage.local.get("seen").then((d) => { const seen = d.seen || {}; seen[location.hostname] = { name: n, price: p || 0, url: location.href, at: Date.now() }; const keys = Object.keys(seen); if (keys.length > 60) delete seen[keys.sort((a, b) => seen[a].at - seen[b].at)[0]]; chrome.storage.local.set({ seen }); }).catch(() => {}); } catch (e) {} }
  setTimeout(rememberProduct, 2500);
  async function bestName() {
    const c = cartNames(); if (c.length) return { name: c[0] + (c.length > 1 ? " y " + (c.length - 1) + " más" : ""), q: c[0] };
    const g = guessName(); if (g && ONPRODUCT()) return { name: g, q: g };
    try { const d = await chrome.storage.local.get("seen"); const s = d.seen && d.seen[location.hostname]; if (s && Date.now() - s.at < 3 * 24 * 3600e3) return { name: s.name, q: s.name, price: s.price, url: s.url }; } catch (e) {}
    return g ? { name: g, q: g } : { name: "Pedido en " + shopName, q: "" };
  }
  // En una ficha de Amazon, el código del producto (ASIN) permite enlazar su historial de precios
  function guessAsin() {
    const m = location.pathname.match(/\/(?:dp|gp\/product|product)\/([A-Z0-9]{10})(?:[\/?]|$)/);
    if (m && /amazon\./.test(location.hostname)) return m[1];
    const el = document.querySelector("[data-asin]"); const a = el && el.getAttribute("data-asin");
    return a && /^[A-Z0-9]{10}$/.test(a) && /amazon\./.test(location.hostname) ? a : null;
  }

  async function saveItem(item) {
    try {
      const data = await chrome.storage.local.get("items");
      const items = Array.isArray(data.items) ? data.items : [];
      items.push(item);
      await chrome.storage.local.set({ items });
      return true;
    } catch (e) { return false; }
  }

  function showBrake(target) {
    open = true;
    const host = document.createElement("div");
    host.id = "notyet-host";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        :host{all:initial}
        *{box-sizing:border-box}
        .back{position:fixed;inset:0;background:rgba(15,20,25,.58);z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:16px;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;font-size:14px;line-height:1.45}
        .box{position:relative;background:#fff;color:#141B24;border-radius:16px;max-width:440px;width:100%;max-height:calc(100vh - 32px);overflow:auto;padding:22px;box-shadow:0 20px 60px rgba(0,0,0,.35);display:flex;flex-direction:column;gap:14px}
        h2{margin:0;font-size:22px;letter-spacing:-.01em;padding-right:28px}
        p{margin:0;color:#5B6673}
        .q{font-weight:600;color:#141B24;font-size:15px}
        label{display:flex;flex-direction:column;gap:4px;font-size:12px;color:#5B6673}
        input{font:inherit;font-size:14px;padding:9px 11px;border:1px solid #D5DBE2;border-radius:10px;color:#141B24;background:#fff;width:100%}
        .cheap{background:#EEF1F4;border-radius:12px;padding:10px 12px;display:flex;flex-direction:column;gap:8px}
        .lbl{font-size:11px;font-weight:600;color:#5B6673;text-transform:uppercase;letter-spacing:.06em}
        .links{display:flex;gap:6px;flex-wrap:wrap}
        .links a{font-size:13px;color:#1F4FD1;background:#fff;border:1px solid #D5DBE2;border-radius:999px;padding:5px 10px;text-decoration:none}
        .row{display:flex;gap:8px;flex-wrap:wrap}
        button{font:inherit;cursor:pointer}
        .main{flex:1 1 170px;background:#167A4A;color:#fff;border:0;border-radius:10px;padding:12px;font-size:15px;font-weight:600}
        .friends{flex:1 1 140px;background:#1F4FD1;color:#fff;border:0;border-radius:10px;padding:12px;font-size:14px;font-weight:600}
        .alt{width:100%;background:transparent;color:#9A3B2E;border:1px solid #D5DBE2;border-radius:10px;padding:11px;font-size:14px}
        .x{position:absolute;top:10px;right:10px;width:32px;height:32px;border:0;background:transparent;color:#5B6673;font-size:22px;line-height:1;border-radius:8px}
        .x:hover{background:#EEF1F4}
        button:focus-visible,input:focus-visible,a:focus-visible{outline:2px solid #1F4FD1;outline-offset:2px}
        .msg{font-size:12px;color:#167A4A}
        .share{background:#EEF4FF;border-radius:12px;padding:10px 12px;display:flex;flex-direction:column;gap:8px}
        .foot{font-size:11px;color:#8A94A3;margin:0}
        .goal{display:none;gap:8px;align-items:center;background:#DDF5E8;color:#167A4A;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:600}
        .goal.on{display:flex}
        @media (prefers-color-scheme:dark){
          .box{background:#18202A;color:#E8EDF2}.q,h2{color:#E8EDF2}p,label,.lbl{color:#97A3B0}
          input{background:#0F1419;color:#E8EDF2;border-color:#2B3642}.cheap{background:#0F1419}
          .links a{background:#18202A;color:#7EA2FF;border-color:#2B3642}.main{background:#2E9E66}.friends{background:#7EA2FF;color:#0F1419}
          .alt{color:#E88A7B;border-color:#2B3642}.x:hover{background:#0F1419}.goal{background:#12301F;color:#4CC98A}
        }
      </style>
      <div class="back" role="dialog" aria-modal="true" aria-labelledby="t">
        <div class="box">
          <button class="x" id="x" type="button" aria-label="Cerrar">&times;</button>
          <h2 id="t">NotYet: espera un segundo</h2>
          <p class="q">¿Lo necesitas o te apetece?</p>
          <p>Si mañana lo sigues queriendo, cómpralo tranquilo. Te avisaremos dentro de 24 horas.</p>
          <label>Qué ibas a comprar<input id="n" maxlength="90" autocomplete="off"></label>
          <label>Precio (€)<input id="p" inputmode="decimal" autocomplete="off" placeholder="0"></label>
          <div class="goal" id="goal"></div>
          <div class="cheap">
            <div class="lbl">Este mismo producto, más barato: enlaces directos</div>
            <div class="links" id="links"></div>
          </div>
          <div class="row">
            <button class="main" id="wait" type="button">Me espero 24 horas</button>
            <button class="friends" id="ask" type="button">¿Lo consultas con tus amigos?</button>
          </div>
          <div class="share" id="share" hidden><div class="lbl">Votación creada: mándala a tu grupo</div><div class="links" id="shl"></div><p class="msg" id="shm"></p></div>
          <button class="alt" id="buy" type="button">Comprar igualmente</button>
          <p class="foot">Sin cuenta, tus datos se quedan en este navegador. No leemos tus pagos ni tu historial.</p>
        </div>
      </div>`;
    document.documentElement.appendChild(host);
    const $ = (id) => root.getElementById(id);
    const num = (s) => { const v = parseFloat(String(s || "").replace(/\s|€/g, "").replace(",", ".")); return Number.isFinite(v) && v > 0 ? Math.round(v * 100) / 100 : 0; };
    let query = "", seenUrl = "";
    const price = guessPrice();
    if (price) $("p").value = String(price).replace(".", ",");
    $("n").value = guessName() || "Pedido en " + shopName;
    bestName().then((b) => { if (!b) return; $("n").value = b.name; query = b.q || ""; seenUrl = b.url || ""; if (!price && b.price) $("p").value = String(b.price).replace(".", ","); drawLinks(); drawGoal(); });

    const drawLinks = () => {
      const base = ($("n").value.trim() && !/^Pedido en /.test($("n").value.trim()) ? $("n").value.trim() : query).replace(/ y \d+ más$/, "");
      const q = encodeURIComponent(base.split(" ").slice(0, 8).join(" "));
      if (!q) { $("links").innerHTML = '<span style="font-size:12px;color:#5B6673">Escribe qué ibas a comprar y te enseño dónde está más barato.</span>'; return; }
      // Enlaces directos a los resultados de este producto en cada sitio (el nombre viaja en la dirección, nada más)
      const L = [
        ["Buscar en " + shopName, "https://www.google.com/search?q=" + encodeURIComponent("site:" + location.hostname.replace(/^www\./, "") + " ") + q],
        ["Google Shopping", "https://www.google.com/search?udm=28&hl=es&gl=es&q=" + q],
        ["idealo", "https://www.idealo.es/resultados.html?q=" + q],
        ["Amazon, de barato a caro", "https://www.amazon.es/s?k=" + q + "&s=price-asc-rank"],
        ["eBay, de barato a caro", "https://www.ebay.es/sch/i.html?_nkw=" + q + "&_sop=15"],
        ["Wallapop (segunda mano)", "https://es.wallapop.com/app/search?keywords=" + q],
        ["Vinted (segunda mano)", "https://www.vinted.es/catalog?search_text=" + q],
        ["Back Market (reacondicionado)", "https://www.backmarket.es/es-es/search?q=" + q]
      ];
      const asin = guessAsin();
      if (asin) L.push(["Historial de precios en Amazon (camelcamelcamel)", "https://es.camelcamelcamel.com/product/" + asin]);
      $("links").innerHTML = L.map(([t, u]) => `<a href="${u}" target="_blank" rel="noopener">${t}</a>`).join("");
    };
    drawLinks();
    $("n").addEventListener("input", drawLinks);

    // Objetivo de ahorro: "si no lo compras, X € más cerca de ..."
    let goal = null, savedMonth = 0;
    const drawGoal = () => {
      const g = $("goal"), p = num($("p").value);
      if (!goal || !p) { g.classList.remove("on"); return; }
      const rest = Math.max(0, goal.amount - savedMonth);
      g.textContent = rest <= 0 ? "Tu objetivo \"" + goal.name + "\" ya está conseguido." : "Si no lo compras, estás " + p.toLocaleString("es-ES") + " € más cerca de " + goal.name + ". Te faltan " + rest.toLocaleString("es-ES") + " €.";
      g.classList.add("on");
    };
    try {
      chrome.storage.local.get(["goal", "items"]).then((d) => {
        goal = d.goal && d.goal.amount > 0 ? d.goal : null;
        const m = new Date(); m.setDate(1); m.setHours(0, 0, 0, 0);
        savedMonth = (Array.isArray(d.items) ? d.items : []).filter((i) => i.status === "skip" && (i.decided || 0) >= m.getTime()).reduce((a, i) => a + (i.price || 0), 0);
        drawGoal();
      }).catch(() => {});
    } catch (e) {}
    $("p").addEventListener("input", drawGoal);

    const close = () => { host.remove(); open = false; };
    const makeItem = (status) => ({
      id: Date.now() * 1000 + Math.floor(Math.random() * 1000),
      name: $("n").value.trim() || guessName(), price: num($("p").value), shop: shopName, url: location.href,
      why: "", start: Date.now(), hours: 24, status
    });
    $("wait").addEventListener("click", async () => {
      const ok = await saveItem(makeItem("wait"));
      close();
      if (!ok) console.warn("NotYet: no se pudo guardar (¿extensión recargada? recarga la página)");
    });
    $("ask").addEventListener("click", async () => {
      const it = makeItem("wait"); const b = $("ask"); b.disabled = true; b.textContent = "Creando la votación…";
      let link = "";
      try { const r = await chrome.runtime.sendMessage({ type: "notyet-poll", body: { title: it.name, price: it.price, shop: shopName, url: seenUrl || location.href, emoji: "🛍️", asker: "" } }); if (r && r.ok) { link = r.link; it.poll = { id: r.id, key: r.key, at: Date.now() }; } } catch (e) {}
      const txt = "¿Me compro esto?\n" + it.name + (it.price ? " - " + it.price.toLocaleString("es-ES") + " €" : "") + " en " + shopName + "\n" + (link ? "Vota con un toque (sí, no o busca más barato): " + link : location.href) + "\nMe lo estoy pensando con NotYet.";
      await saveItem(it);
      const enc = encodeURIComponent(txt), u = encodeURIComponent(link || location.href);
      $("shl").innerHTML = [["WhatsApp", "https://wa.me/?text=" + enc], ["Telegram", "https://t.me/share/url?url=" + u + "&text=" + enc], ["Facebook", "https://www.facebook.com/sharer/sharer.php?u=" + u], ["Correo", "mailto:?subject=" + encodeURIComponent("¿Me lo compro?") + "&body=" + enc]].map(([t, h]) => `<a href="${h}" target="_blank" rel="noopener">${t}</a>`).join("") + '<a href="#" id="cp">Copiar (Instagram y otros)</a>';
      $("share").hidden = false; b.textContent = link ? "Votación creada" : "Sin conexión: comparte el enlace de la tienda"; 
      $("shm").textContent = link ? "Tus amigos votan sin instalar nada. Verás el resultado en notyetapp.app/app, en Comité." : "";
      $("cp").addEventListener("click", async (e) => { e.preventDefault(); try { await navigator.clipboard.writeText(txt); $("shm").textContent = "Copiado. Pégalo en tu grupo."; } catch (x) {} });
    });
    $("buy").addEventListener("click", async () => {
      await saveItem(makeItem("impulse"));
      close();
      bypassUntil = Date.now() + BYPASS_MS;
      let btn = target && target.isConnected ? target : null;
      if (!btn) { const all = findBuyButtonsNow(); btn = all[0] || null; }
      if (btn) { try { btn.click(); } catch (e) {} }
      else { try { chrome.storage.local.set({ lastHint: "Vuelve a pulsar el botón de comprar; no te frenaremos en 2 minutos." }); } catch (e) {} }
    });
    $("x").addEventListener("click", close);
    root.querySelector(".back").addEventListener("keydown", (e) => { if (e.key === "Escape") { e.stopPropagation(); close(); } });
    root.querySelector(".back").addEventListener("click", (e) => { if (e.target === e.currentTarget) close(); });
    $("wait").focus();
  }

  function onClick(e) {
    if (open || Date.now() < bypassUntil) return;
    // composedPath ve también dentro de componentes web (shadow DOM) de la tienda
    const path = e.composedPath ? e.composedPath() : [e.target];
    let target = null;
    for (const el of path) {
      if (!el || el.nodeType !== 1) continue;
      if (el.id === "notyet-host") return;
      if (isClickable(el) && isBuyText(textOf(el))) { target = el; break; }
      if (el === document.body) break;
    }
    if (!target) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    showBrake(target);
  }
  function onSubmit(e) {
    if (open || Date.now() < bypassUntil) return;
    const btn = e.submitter;
    if (btn && isBuyText(textOf(btn))) { e.preventDefault(); e.stopImmediatePropagation(); showBrake(btn); }
  }
  document.addEventListener("click", onClick, true);
  document.addEventListener("submit", onSubmit, true);
})();
