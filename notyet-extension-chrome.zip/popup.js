"use strict";
const H = 3600e3;
const fmt = (n) => Number(n || 0).toLocaleString("es-ES", { maximumFractionDigits: 2 }) + " €";
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const LABEL = { skip: ["Ahorrado", "ok"], buy: ["Comprado", "no"], impulse: ["Sin esperar", "no"] };

let goal = null;
async function getItems() {
  const d = await chrome.storage.local.get(["items", "lastHint", "goal"]);
  goal = d.goal && d.goal.amount > 0 ? d.goal : null;
  if (d.lastHint) {
    const h = document.getElementById("hint"); h.textContent = d.lastHint; h.hidden = false;
    chrome.storage.local.remove("lastHint");
  }
  return Array.isArray(d.items) ? d.items : [];
}

async function render() {
  const items = await getItems();
  const m = new Date(); m.setDate(1); m.setHours(0, 0, 0, 0);
  const saved = items.filter((i) => i.status === "skip" && (i.decided || 0) >= m.getTime()).reduce((a, i) => a + (i.price || 0), 0);
  const stopped = items.filter((i) => i.status !== "impulse").length;
  document.getElementById("saved").textContent = fmt(saved);
  document.getElementById("count").textContent = stopped + (stopped === 1 ? " freno" : " frenos");
  renderGoal(saved);

  const wait = items.filter((i) => i.status === "wait").sort((a, b) => a.start - b.start);
  const list = document.getElementById("list");
  list.innerHTML = wait.length ? wait.map((it) => {
    const left = it.start + (it.hours || 24) * H - Date.now();
    const ready = left <= 0;
    const when = ready ? "Ya puedes decidir" : "Faltan " + Math.floor(left / H) + " h " + Math.floor((left % H) / 60000) + " min";
    return `<div class="item${ready ? " ready" : ""}" data-id="${it.id}">
      <div class="top"><span class="name">${esc(it.name)}</span><span class="price">${it.price ? fmt(it.price) : ""}</span></div>
      <div class="meta">${esc(it.shop || "")} - ${when}</div>
      <div class="row">
        <button type="button" class="save" data-act="skip">No lo compro</button>
        <button type="button" class="buy" data-act="buy">Lo compro</button>
        ${it.url ? '<button type="button" class="link" data-act="open">Ver producto</button>' : ""}
      </div></div>`;
  }).join("") : '<div class="empty">Nada en espera. Saltaré la próxima vez que vayas a pagar.</div>';

  const done = items.filter((i) => i.status !== "wait").sort((a, b) => (b.decided || b.start || 0) - (a.decided || a.start || 0)).slice(0, 6);
  const hist = document.getElementById("hist");
  hist.innerHTML = done.length ? done.map((it) => {
    const [txt, cls] = LABEL[it.status] || ["", "no"];
    return `<div><span class="name">${esc(it.name)}</span><span><span class="pill ${cls}">${txt}</span> <span class="price">${it.price ? fmt(it.price) : ""}</span></span></div>`;
  }).join("") : '<p class="note">Aquí verás lo que decidiste comprar o descartar.</p>';
}

// Objetivo de ahorro: cada compra descartada acerca al usuario a algo que quiere
function renderGoal(saved) {
  const box = document.getElementById("goalBox");
  if (goal) {
    const pct = Math.min(100, Math.round(saved / goal.amount * 100));
    box.innerHTML = `<div class="t">${esc(goal.name)}</div><div class="bar"><i style="width:${pct}%"></i></div>
      <div class="meta">${pct >= 100 ? "Objetivo conseguido con lo que has decidido no gastar" : "Te faltan " + fmt(goal.amount - saved) + " de " + fmt(goal.amount)}</div>
      <button type="button" class="link" id="goalEdit">Cambiar objetivo</button>`;
    document.getElementById("goalEdit").addEventListener("click", () => { goal = null; renderGoal(saved); });
  } else {
    box.innerHTML = `<div class="t">Ponte un objetivo</div><div class="meta">Un viaje, la boda, un fondo de emergencia. Cada compra que descartes te acercará.</div>
      <form id="goalForm"><input id="goalName" maxlength="40" placeholder="Viaje a Lisboa" required><div class="row"><input id="goalAmount" inputmode="decimal" placeholder="500 €" required><button type="submit">Guardar</button></div></form>`;
    document.getElementById("goalForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const name = document.getElementById("goalName").value.trim();
      const amount = parseFloat(document.getElementById("goalAmount").value.replace(/\s|€/g, "").replace(",", "."));
      if (!name || !(amount > 0)) return;
      await chrome.storage.local.set({ goal: { name, amount: Math.round(amount * 100) / 100 } });
      render();
    });
  }
}

document.getElementById("list").addEventListener("click", async (e) => {
  const b = e.target.closest("button"); if (!b) return;
  const id = Number(b.closest(".item").dataset.id);
  const d = await chrome.storage.local.get("items");
  const items = Array.isArray(d.items) ? d.items : [];
  const it = items.find((i) => i.id === id); if (!it) return;
  if (b.dataset.act === "open") { if (it.url) chrome.tabs.create({ url: it.url }); return; }
  it.status = b.dataset.act; it.decided = Date.now();
  await chrome.storage.local.set({ items });
  chrome.alarms.clear("esperate-" + id);
  chrome.notifications.clear("esperate-" + id);
  if (it.status === "buy" && it.url) chrome.tabs.create({ url: it.url });
  render();
});

// Resumen anónimo para el piloto: solo recuentos y nombres de tiendas, nunca productos ni enlaces
function pilotSummary(items) {
  const m = new Date(); m.setDate(1); m.setHours(0, 0, 0, 0);
  const c = (f) => items.filter(f).length;
  const saved = items.filter((i) => i.status === "skip" && (i.decided || 0) >= m.getTime()).reduce((a, i) => a + (i.price || 0), 0);
  const shops = {};
  items.forEach((i) => { const s = i.shop || "Otra"; shops[s] = (shops[s] || 0) + 1; });
  const shopList = Object.entries(shops).sort((a, b) => b[1] - a[1]).map(([s, n]) => `${s} (${n})`).join(", ") || "ninguna";
  const v = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || "";
  return [
    `NotYet ${v} - resumen del piloto - ${new Date().toLocaleDateString("es-ES")}`,
    `Frenos totales: ${items.length}`,
    `Esperas de 24 h: ${c((i) => i.status === "wait" || i.status === "skip" || i.status === "buy")}`,
    `Compras evitadas: ${c((i) => i.status === "skip")}`,
    `Compradas tras esperar: ${c((i) => i.status === "buy")}`,
    `Compradas sin esperar: ${c((i) => i.status === "impulse")}`,
    `En espera ahora: ${c((i) => i.status === "wait")}`,
    `Ahorro del mes: ${fmt(saved)}`,
    `Tiendas: ${shopList}`
  ].join("\n");
}
document.getElementById("copySummary").addEventListener("click", async () => {
  const d = await chrome.storage.local.get("items");
  const txt = pilotSummary(Array.isArray(d.items) ? d.items : []);
  const box = document.getElementById("summaryBox"), note = document.getElementById("summaryNote");
  box.value = txt; box.hidden = false; note.hidden = false;
  try { await navigator.clipboard.writeText(txt); note.textContent = "Copiado. Pégalo en el formulario semanal del piloto."; }
  catch (e) { box.select(); note.textContent = "Selecciona el texto y cópialo con Ctrl+C."; }
});

render();
