// NotYet - vínculo con tu cuenta. Solo se ejecuta en notyetapp.app: si has entrado en tu cuenta en la app,
// la extensión guarda tu sesión para que lo que frenas en el ordenador aparezca también en la app.
(() => {
  const read = () => { try { const s = JSON.parse(localStorage.getItem("notyet.session") || "null"); return s && s.token ? { token: s.token, email: s.email || "" } : null; } catch (e) { return null; } };
  let last = "";
  const tick = () => {
    const s = read(), k = s ? s.token : "";
    if (k === last) return; last = k;
    try { chrome.runtime.sendMessage({ type: "notyet-link", session: s }); } catch (e) {}
  };
  document.documentElement.dataset.notyetExt = chrome.runtime.getManifest().version;
  tick(); setInterval(tick, 4000);
})();
