// NotYet - tiendas afines: propone dónde mirar el MISMO tipo de producto en tiendas de un nivel parecido.
// Un cinturón de Hermès no lleva a Alibaba ni a una tienda de bricolaje: lleva a tiendas de lujo, a la web oficial y a segunda mano de lujo verificada.
// Se usa en la extensión (content.js) y en la app (mismo bloque). Todo es local: el nombre del producto solo viaja en la dirección de búsqueda.
(function (root) {
  "use strict";
  const N = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9&' ]+/g, " ").replace(/\s+/g, " ").trim();
  const has = (t, words) => words.some((w) => (" " + t + " ").includes(" " + w) );

  // Marcas por nivel (texto normalizado). Ampliable.
  const BR = {
    lujo: ["hermes", "louis vuitton", "gucci", "prada", "chanel", "dior", "loewe", "balenciaga", "saint laurent", "ysl", "bottega veneta", "celine", "fendi", "givenchy", "valentino", "versace", "burberry", "cartier", "rolex", "omega", "patek philippe", "audemars piguet", "tag heuer", "tiffany", "bulgari", "bvlgari", "van cleef", "moncler", "miu miu", "goyard", "berluti", "tom ford", "brunello cucinelli", "loro piana", "chloe", "alexander mcqueen", "jimmy choo", "manolo blahnik", "christian louboutin", "louboutin", "dolce", "dolce & gabbana", "salvatore ferragamo", "ferragamo", "max mara", "zegna", "montblanc", "breitling", "iwc", "hublot", "golden goose", "off white", "jacquemus", "the row", "bang & olufsen", "vertu"],
    premium: ["hugo boss", "boss", "ralph lauren", "polo ralph lauren", "tommy hilfiger", "calvin klein", "michael kors", "coach", "furla", "guess", "massimo dutti", "scalpers", "el ganso", "lacoste", "tous", "longchamp", "kate spade", "armani exchange", "emporio armani", "diesel", "levi's", "levis", "hackett", "barbour", "the north face", "patagonia", "on running", "hoka", "apple", "iphone", "macbook", "ipad", "airpods", "sony", "bose", "dyson", "samsung galaxy s", "garmin", "sonos", "nespresso", "kitchenaid", "smeg", "le creuset", "ray ban", "ray-ban", "oakley", "pandora", "swarovski", "uterque", "sandro", "maje", "ba&sh", "cos ", "arket", "camper", "ecoalf", "lululemon", "canada goose", "stone island", "tissot", "seiko", "longines"],
    low: ["shein", "temu", "aliexpress", "alibaba", "wish", "primark", "lefties", "action ", "tedi", "pepco", "kiabi", "sfera low"]
  };
  const HOST_TIER = { "hermes.com": "lujo", "louisvuitton.com": "lujo", "gucci.com": "lujo", "prada.com": "lujo", "chanel.com": "lujo", "dior.com": "lujo", "loewe.com": "lujo", "farfetch.com": "lujo", "mytheresa.com": "lujo", "net-a-porter.com": "lujo", "mrporter.com": "lujo", "ysl.com": "lujo", "balenciaga.com": "lujo", "cartier.com": "lujo", "rolex.com": "lujo", "tiffany.com": "lujo",
    "massimodutti.com": "premium", "ralphlauren.es": "premium", "hugoboss.com": "premium", "apple.com": "premium", "elcorteingles.es": "premium", "scalpers.com": "premium", "tous.com": "premium", "dyson.es": "premium",
    "shein.com": "low", "temu.com": "low", "aliexpress.com": "low", "alibaba.com": "low", "wish.com": "low", "primark.com": "low", "lefties.com": "low" };

  // Categorías por palabras del producto
  const CAT = [
    ["joyeria", "Relojes y joyería", ["reloj", "relojes", "anillo", "pulsera", "collar", "pendiente", "pendientes", "joya", "joyas", "gemelos", "broche", "watch"]],
    ["accesorios", "Bolsos y accesorios", ["cinturon", "cinturones", "bolso", "bolsos", "cartera", "billetera", "monedero", "gafas", "panuelo", "foulard", "corbata", "pajarita", "gorra", "sombrero", "bufanda", "guantes", "maleta", "mochila", "belt", "bag", "tote", "clutch", "sunglasses"]],
    ["moda", "Ropa y calzado", ["camisa", "camiseta", "vestido", "falda", "pantalon", "pantalones", "vaquero", "vaqueros", "jean", "jeans", "chaqueta", "cazadora", "abrigo", "gabardina", "jersey", "sudadera", "blazer", "traje", "americana", "zapato", "zapatos", "bota", "botas", "botines", "sandalia", "sandalias", "mocasin", "mocasines", "sneaker", "sneakers", "deportivas", "ropa", "lenceria", "bikini", "banador", "polo", "chaleco", "top", "blusa", "shorts", "dress", "jacket", "coat", "shirt", "shoes"]],
    ["belleza", "Belleza y perfumes", ["perfume", "colonia", "eau de", "crema", "serum", "labial", "barra de labios", "maquillaje", "base de maquillaje", "mascara de pestanas", "champu", "acondicionador", "esmalte", "contorno", "fragancia", "skincare"]],
    ["tech", "Tecnología", ["movil", "iphone", "smartphone", "telefono", "portatil", "macbook", "ordenador", "pc ", "tablet", "ipad", "auricular", "auriculares", "airpods", "televisor", "tv ", "television", "monitor", "consola", "playstation", "ps5", "xbox", "nintendo", "switch", "camara", "objetivo", "smartwatch", "apple watch", "altavoz", "teclado", "raton", "impresora", "router", "disco duro", "ssd", "tarjeta grafica", "dron", "kindle", "ebook reader"]],
    ["hogar", "Casa y decoración", ["sofa", "mesa", "silla", "sillas", "lampara", "colchon", "cama", "alfombra", "cortina", "cortinas", "sarten", "cacerola", "olla", "cafetera", "aspiradora", "robot aspirador", "vajilla", "estanteria", "mueble", "edredon", "almohada", "toalla", "toallas", "espejo", "jarron", "vela", "freidora", "batidora", "microondas", "frigorifico", "lavadora", "lavavajillas", "horno", "cuchillo", "cuchillos"]],
    ["bricolaje", "Bricolaje y herramientas", ["taladro", "herramienta", "herramientas", "atornillador", "destornillador", "pintura", "tornillo", "tornillos", "sierra", "bricolaje", "escalera", "grifo", "azulejo", "lijadora", "amoladora", "martillo", "cinta metrica", "llave inglesa"]],
    ["jardin", "Jardín y terraza", ["maceta", "macetas", "planta", "plantas", "cesped", "barbacoa", "manguera", "jardin", "terraza", "cortacesped", "tumbona", "parasol"]],
    ["deporte", "Deporte", ["running", "bicicleta", "bici", "raqueta", "padel", "tenis", "pesas", "mancuerna", "mancuernas", "esterilla", "gimnasio", "futbol", "balon", "deporte", "chandal", "zapatillas de correr", "zapatillas running", "patinete", "casco de bici", "neopreno", "esqui", "snowboard", "golf", "yoga"]],
    ["peques", "Bebés y juguetes", ["juguete", "juguetes", "lego", "muneca", "peluche", "carrito de bebe", "cochecito", "silla de paseo", "bebe", "infantil", "puzzle", "playmobil", "cuna", "trona"]],
    ["libros", "Libros, música y cine", ["libro", "libros", "novela", "comic", "manga", "vinilo", "disco", "blu ray", "dvd"]],
    ["viajes", "Viajes", ["vuelo", "vuelos", "hotel", "hoteles", "billete de avion", "viaje", "crucero", "apartamento turistico", "escapada"]],
    ["mascotas", "Mascotas", ["perro", "gato", "pienso", "mascota", "arena para gatos", "correa", "rascador", "acuario"]],
    ["motor", "Motor", ["neumatico", "neumaticos", "coche", "moto", "casco de moto", "aceite de motor", "llantas", "baca", "portabicis"]],
    ["super", "Supermercado", ["supermercado", "compra semanal", "leche", "aceite de oliva", "detergente", "panales", "cerveza", "vino"]]
  ];
  const HOST_CAT = { "hermes.com": "accesorios", "louisvuitton.com": "accesorios", "farfetch.com": "moda", "zara.com": "moda", "mango.com": "moda", "hm.com": "moda", "zalando.es": "moda", "massimodutti.com": "moda", "shein.com": "moda", "pccomponentes.com": "tech", "mediamarkt.es": "tech", "apple.com": "tech", "backmarket.es": "tech", "ikea.com": "hogar", "leroymerlin.es": "bricolaje", "bricomart.es": "bricolaje", "manomano.es": "bricolaje", "decathlon.es": "deporte", "sephora.es": "belleza", "douglas.es": "belleza", "druni.es": "belleza", "primor.eu": "belleza", "notino.es": "belleza", "booking.com": "viajes", "ryanair.com": "viajes", "vueling.com": "viajes", "iberia.com": "viajes", "tiendanimal.es": "mascotas", "kiwoko.com": "mascotas", "zooplus.es": "mascotas", "casadellibro.com": "libros", "fnac.es": "libros", "mercadona.es": "super", "carrefour.es": "super", "norauto.es": "motor", "rolex.com": "joyeria", "tous.com": "joyeria", "pandora.net": "joyeria", "cartier.com": "joyeria" };
  const APP_CAT = { ropa: "moda", tech: "tech", deporte: "deporte", viajes: "viajes", belleza: "belleza", casa: "hogar", motor: "motor", ocio: "tech", mascotas: "mascotas", peques: "peques", jardin: "jardin", lujo: "accesorios", reformas: "bricolaje", super: "super", formacion: "libros", regalos: "accesorios" };

  // Tiendas: [nombre, dirección de búsqueda con {q}, qué aporta]. Si no hay buscador fiable, se busca dentro de la tienda con Google (site:).
  const G = (dom) => "https://www.google.com/search?hl=es&q=" + encodeURIComponent("site:" + dom + " ") + "{q}";
  const S = {
    gshop: ["Google Shopping", "https://www.google.com/search?udm=28&hl=es&gl=es&q={q}", "el mismo producto en todas las tiendas"],
    idealo: ["idealo", "https://www.idealo.es/resultados.html?q={q}", "comparador de precios"],
    oficial: ["Web oficial de la marca", "https://www.google.com/search?hl=es&q={b}+tienda+oficial+{q}", "precio y garantía de la marca"],
    farfetch: ["Farfetch", "https://www.farfetch.com/es/shopping/search/items.aspx?q={q}", "boutiques de lujo de todo el mundo"],
    mytheresa: ["Mytheresa", G("mytheresa.com"), "lujo, con rebajas de temporada"],
    netaporter: ["Net-a-Porter / Mr Porter", "https://www.google.com/search?hl=es&q=" + encodeURIComponent("site:net-a-porter.com OR site:mrporter.com ") + "{q}", "lujo con devoluciones fáciles"],
    eci: ["El Corte Inglés", G("elcorteingles.es"), "grandes marcas con garantía y tienda física"],
    outnet: ["The Outnet / Yoox (outlet de lujo)", "https://www.google.com/search?hl=es&q=" + encodeURIComponent("site:theoutnet.com OR site:yoox.com ") + "{q}", "temporadas pasadas de las mismas marcas"],
    vestiaire: ["Vestiaire Collective", "https://es.vestiairecollective.com/search/?q={q}", "segunda mano de lujo con autenticación"],
    chrono24: ["Chrono24", G("chrono24.es"), "relojes nuevos y de segunda mano verificados"],
    zalando: ["Zalando", "https://www.zalando.es/catalogo/?q={q}", "muchas marcas, devolución gratis"],
    zalandopre: ["Zalando (marcas premium)", "https://www.zalando.es/catalogo/?q={q}&order=price", "mismo estilo, marcas de nivel parecido"],
    asos: ["ASOS", G("asos.com"), "moda y marcas propias"],
    vinted: ["Vinted (segunda mano)", "https://www.vinted.es/catalog?search_text={q}", "segunda mano de moda"],
    wallapop: ["Wallapop (segunda mano)", "https://es.wallapop.com/app/search?keywords={q}", "segunda mano cerca de ti"],
    amazon: ["Amazon", "https://www.amazon.es/s?k={q}", "envío rápido"],
    amazonlow: ["Amazon, de barato a caro", "https://www.amazon.es/s?k={q}&s=price-asc-rank", "lo más barato primero"],
    ebay: ["eBay, de barato a caro", "https://www.ebay.es/sch/i.html?_nkw={q}&_sop=15", "nuevo y de segunda mano"],
    sephora: ["Sephora", G("sephora.es"), "perfumería de marcas de prestigio"],
    douglas: ["Douglas", G("douglas.es"), "perfumería con ofertas frecuentes"],
    notino: ["Notino", G("notino.es"), "perfumes y cosmética a buen precio"],
    primor: ["Primor", G("primor.eu"), "perfumería a precio bajo"],
    druni: ["Druni", G("druni.es"), "perfumería a precio bajo"],
    apple: ["Apple", G("apple.com/es"), "precio oficial y reacondicionados de Apple"],
    pccomp: ["PcComponentes", "https://www.pccomponentes.com/buscar/?query={q}", "tecnología con buen servicio"],
    mediamarkt: ["MediaMarkt", "https://www.mediamarkt.es/es/search.html?query={q}", "tienda física y ofertas"],
    fnac: ["Fnac", "https://www.fnac.es/SearchResult/ResultList.aspx?Search={q}", "tecnología y cultura"],
    backmarket: ["Back Market (reacondicionado)", "https://www.backmarket.es/es-es/search?q={q}", "reacondicionado con garantía"],
    ikea: ["IKEA", "https://www.ikea.com/es/es/search/?q={q}", "hogar a buen precio"],
    maisons: ["Maisons du Monde", G("maisonsdumonde.com/ES"), "decoración con estilo"],
    westwing: ["Westwing", G("westwing.es"), "diseño y decoración premium"],
    leroy: ["Leroy Merlin", G("leroymerlin.es"), "bricolaje y reformas"],
    bricomart: ["Bricomart", G("bricomart.es"), "bricolaje profesional a buen precio"],
    manomano: ["ManoMano", G("manomano.es"), "bricolaje y jardín online"],
    decathlon: ["Decathlon", "https://www.decathlon.es/es/search?Ntt={q}", "deporte a buen precio"],
    sprinter: ["Sprinter", G("sprinter.es"), "deporte y zapatillas"],
    jd: ["JD Sports", G("jdsports.es"), "zapatillas y marcas deportivas"],
    juguettos: ["Juguettos", G("juguettos.com"), "juguetería"],
    casadellibro: ["Casa del Libro", G("casadellibro.com"), "librería"],
    booking: ["Booking", "https://www.booking.com/searchresults.es.html?ss={q}", "hoteles"],
    gflights: ["Google Vuelos", "https://www.google.com/travel/flights?hl=es&q=" + encodeURIComponent("vuelos ") + "{q}", "compara vuelos de todas las aerolíneas"],
    skyscanner: ["Skyscanner", G("skyscanner.es"), "comparador de vuelos"],
    tiendanimal: ["Tiendanimal", G("tiendanimal.es"), "mascotas"],
    zooplus: ["Zooplus", G("zooplus.es"), "mascotas a buen precio"],
    kiwoko: ["Kiwoko", G("kiwoko.com"), "mascotas con tienda física"],
    norauto: ["Norauto", G("norauto.es"), "motor y recambios"],
    oscaro: ["Oscaro", G("oscaro.es"), "recambios online"],
    carrefour: ["Carrefour", G("carrefour.es"), "supermercado online"],
    tous: ["TOUS", G("tous.com"), "joyería"],
    pandora: ["Pandora", G("pandora.net/es-es"), "joyería"]
  };
  // Qué tiendas tienen sentido para cada categoría y nivel (por orden)
  const PLAN = {
    accesorios: { lujo: ["oficial", "farfetch", "mytheresa", "netaporter", "eci", "outnet", "vestiaire"], premium: ["oficial", "eci", "farfetch", "zalandopre", "outnet", "vestiaire", "vinted"], medio: ["gshop", "zalando", "eci", "amazon", "vinted", "wallapop"], low: ["gshop", "amazonlow", "zalando", "vinted", "wallapop"] },
    moda: { lujo: ["oficial", "farfetch", "mytheresa", "netaporter", "eci", "outnet", "vestiaire"], premium: ["oficial", "eci", "zalandopre", "farfetch", "outnet", "vestiaire", "vinted"], medio: ["gshop", "zalando", "eci", "asos", "vinted", "wallapop"], low: ["gshop", "zalando", "asos", "amazonlow", "vinted", "wallapop"] },
    joyeria: { lujo: ["oficial", "eci", "farfetch", "mytheresa", "chrono24", "vestiaire"], premium: ["oficial", "eci", "chrono24", "tous", "vestiaire", "gshop"], medio: ["gshop", "tous", "pandora", "eci", "amazon", "wallapop"], low: ["gshop", "amazonlow", "wallapop", "vinted"] },
    belleza: { lujo: ["oficial", "sephora", "eci", "douglas", "notino"], premium: ["sephora", "douglas", "eci", "notino", "primor", "druni"], medio: ["primor", "druni", "notino", "douglas", "amazon", "gshop"], low: ["primor", "druni", "notino", "amazonlow", "gshop"] },
    tech: { lujo: ["oficial", "eci", "mediamarkt", "fnac", "backmarket", "idealo"], premium: ["oficial", "eci", "mediamarkt", "pccomp", "fnac", "backmarket", "idealo"], medio: ["gshop", "idealo", "pccomp", "mediamarkt", "amazon", "backmarket", "wallapop"], low: ["gshop", "idealo", "amazonlow", "pccomp", "backmarket", "wallapop", "ebay"] },
    hogar: { lujo: ["oficial", "westwing", "eci", "maisons", "gshop"], premium: ["westwing", "eci", "maisons", "oficial", "gshop", "wallapop"], medio: ["ikea", "maisons", "eci", "amazon", "gshop", "wallapop"], low: ["ikea", "amazonlow", "gshop", "wallapop"] },
    bricolaje: { lujo: ["leroy", "manomano", "bricomart", "amazon", "gshop"], premium: ["leroy", "manomano", "bricomart", "amazon", "gshop"], medio: ["leroy", "bricomart", "manomano", "amazon", "wallapop"], low: ["bricomart", "manomano", "amazonlow", "wallapop"] },
    jardin: { lujo: ["leroy", "eci", "manomano", "gshop"], premium: ["leroy", "eci", "manomano", "gshop"], medio: ["leroy", "ikea", "manomano", "amazon", "wallapop"], low: ["leroy", "manomano", "amazonlow", "wallapop"] },
    deporte: { lujo: ["oficial", "eci", "zalandopre", "jd", "gshop"], premium: ["oficial", "eci", "jd", "zalando", "sprinter", "decathlon", "wallapop"], medio: ["decathlon", "sprinter", "zalando", "amazon", "wallapop"], low: ["decathlon", "amazonlow", "wallapop", "vinted"] },
    peques: { lujo: ["eci", "oficial", "gshop", "vinted"], premium: ["eci", "juguettos", "gshop", "amazon", "vinted", "wallapop"], medio: ["juguettos", "amazon", "eci", "gshop", "vinted", "wallapop"], low: ["amazonlow", "juguettos", "vinted", "wallapop"] },
    libros: { lujo: ["casadellibro", "fnac", "amazon", "wallapop"], premium: ["casadellibro", "fnac", "amazon", "wallapop"], medio: ["casadellibro", "fnac", "amazon", "wallapop"], low: ["amazonlow", "wallapop", "casadellibro"] },
    viajes: { lujo: ["oficial", "booking", "gflights"], premium: ["gflights", "skyscanner", "booking"], medio: ["gflights", "skyscanner", "booking"], low: ["gflights", "skyscanner", "booking"] },
    mascotas: { lujo: ["tiendanimal", "kiwoko", "zooplus", "amazon"], premium: ["tiendanimal", "kiwoko", "zooplus", "amazon"], medio: ["zooplus", "tiendanimal", "kiwoko", "amazon"], low: ["zooplus", "amazonlow", "tiendanimal"] },
    motor: { lujo: ["oficial", "norauto", "oscaro", "gshop"], premium: ["norauto", "oscaro", "gshop", "wallapop"], medio: ["norauto", "oscaro", "amazon", "wallapop"], low: ["oscaro", "amazonlow", "wallapop"] },
    super: { lujo: ["carrefour", "eci", "amazon"], premium: ["carrefour", "eci", "amazon"], medio: ["carrefour", "amazon", "gshop"], low: ["carrefour", "amazonlow", "gshop"] },
    otro: { lujo: ["oficial", "eci", "farfetch", "gshop", "vestiaire"], premium: ["oficial", "eci", "gshop", "idealo", "wallapop"], medio: ["gshop", "idealo", "amazon", "ebay", "wallapop"], low: ["gshop", "idealo", "amazonlow", "ebay", "wallapop"] }
  };
  const TIER_TXT = { lujo: "lujo", premium: "gama alta", medio: "gama media", low: "precio bajo" };
  const LUX_PRICE = { accesorios: 400, moda: 700, joyeria: 1500, belleza: 180, tech: 2500, hogar: 2500, deporte: 600 };
  const PRE_PRICE = { accesorios: 120, moda: 180, joyeria: 250, belleza: 70, tech: 900, hogar: 700, deporte: 150, peques: 300, motor: 600 };

  function brandOf(t) { for (const tier of ["lujo", "premium", "low"]) for (const b of BR[tier]) if ((" " + t + " ").includes(" " + b.trim() + " ")) return { b: b.trim(), tier }; return null; }
  function detect(o) {
    o = o || {}; const t = N([o.brand, o.name].filter(Boolean).join(" ")), host = String(o.host || "").replace(/^www\./, "").toLowerCase();
    const hk = (map) => Object.keys(map).find((h) => host === h || host.endsWith("." + h));
    let cat = ""; for (const [k, , w] of CAT) if (has(t, w)) { cat = k; break; }
    if (!cat && hk(HOST_CAT)) cat = HOST_CAT[hk(HOST_CAT)];
    if (!cat && o.cat && APP_CAT[o.cat]) cat = APP_CAT[o.cat];
    if (!cat) cat = "otro";
    const br = brandOf(t) || (o.shop ? brandOf(N(o.shop)) : null);
    let tier = br ? br.tier : hk(HOST_TIER) ? HOST_TIER[hk(HOST_TIER)] : "";
    const price = Number(o.price) || 0;
    if (!tier && o.cat === "lujo") tier = "lujo";
    if (!tier && price) tier = LUX_PRICE[cat] && price >= LUX_PRICE[cat] ? "lujo" : PRE_PRICE[cat] && price >= PRE_PRICE[cat] ? "premium" : "medio";
    if (!tier) tier = "medio";
    // Una marca de lujo nunca baja de nivel por el precio
    return { cat, catLabel: (CAT.find((c) => c[0] === cat) || [0, "Otros"])[1], tier, tierLabel: TIER_TXT[tier], brand: br ? br.b : "" };
  }
  const titleCase = (s) => s.replace(/\b[a-z]/g, (m) => m.toUpperCase());
  const BRAND_NAME = { hermes: "Hermès", iphone: "Apple", macbook: "Apple", ipad: "Apple", airpods: "Apple", ysl: "Saint Laurent", "saint laurent": "Saint Laurent", levis: "Levi's", "levi's": "Levi's", boss: "BOSS", "hugo boss": "BOSS", "ray ban": "Ray-Ban", "ray-ban": "Ray-Ban", dolce: "Dolce & Gabbana", "dolce & gabbana": "Dolce & Gabbana", chloe: "Chloé", "off white": "Off-White", bvlgari: "Bulgari", louboutin: "Christian Louboutin", "polo ralph lauren": "Ralph Lauren", "samsung galaxy s": "Samsung", tous: "TOUS", "el ganso": "El Ganso", "ba&sh": "ba&sh", "on running": "On", "cos": "COS", "arket": "Arket", "the north face": "The North Face" };
  const brandName = (b) => BRAND_NAME[b] || titleCase(b);
  function recommend(o) {
    const d = detect(o); const name = String(o.name || "").replace(/ y \d+ más$/, "").trim();
    const q = encodeURIComponent(name.split(/\s+/).slice(0, 9).join(" ")), b = encodeURIComponent(d.brand ? brandName(d.brand) : "");
    const host = String(o.host || "").replace(/^www\./, "");
    let ids = (PLAN[d.cat] || PLAN.otro)[d.tier].slice();
    if (!d.brand) ids = ids.filter((k) => k !== "oficial");
    const links = [];
    if (host && o.here !== false) links.push({ t: "Buscar en " + (o.shop || host), u: "https://www.google.com/search?hl=es&q=" + encodeURIComponent("site:" + host + " ") + q, k: "tienda", why: "otras tallas, colores o modelos en esta tienda" });
    for (const k of ids) { const s = S[k]; if (!s) continue; if (host && s[1].includes(host)) continue; links.push({ t: k === "oficial" ? "Web oficial de " + brandName(d.brand) : s[0], u: s[1].replace(/\{q\}/g, q).replace(/\{b\}/g, b), k, why: s[2] }); }
    const why = d.tier === "lujo" ? "Producto de lujo: te enseño solo tiendas de lujo, la web oficial y segunda mano de lujo con autenticación." : d.tier === "premium" ? "Gama alta: tiendas de marcas de nivel parecido y outlets de esas mismas marcas." : d.tier === "low" ? "Precio bajo: comparadores y lo más barato primero." : "Tiendas de " + d.catLabel.toLowerCase() + " de gama parecida y segunda mano.";
    return Object.assign(d, { links, why });
  }
  root.NYT = { detect, recommend, norm: N, brandName };
})(typeof window !== "undefined" ? window : globalThis);
